-- BOULETAD STORE: database starter for Supabase
-- Run in Supabase SQL Editor after creating a project.
create extension if not exists pgcrypto;

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.store_settings (
  id integer primary key default 1 check (id = 1),
  exchange_rate numeric(12,4) not null default 240 check (exchange_rate > 0),
  whatsapp_phone text not null default '213556274884',
  updated_at timestamptz not null default now()
);
insert into public.store_settings (id) values (1) on conflict (id) do nothing;

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name_ar text not null,
  name_es text not null default '',
  category_id text not null check (category_id in ('kitchenware','electricity','plumbing','hardware','decor','appliances')),
  price_dzd numeric(14,2) not null default 0 check (price_dzd >= 0),
  description_ar text not null default '',
  description_es text not null default '',
  image_urls jsonb not null default '[]'::jsonb,
  video_url text not null default '',
  badge text not null default '',
  featured boolean not null default false,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.is_store_admin()
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.admin_users where user_id = auth.uid()); $$;
revoke all on function public.is_store_admin() from public;
grant execute on function public.is_store_admin() to anon, authenticated;

alter table public.admin_users enable row level security;
alter table public.store_settings enable row level security;
alter table public.products enable row level security;

drop policy if exists "admins read admin list" on public.admin_users;
create policy "admins read admin list" on public.admin_users for select to authenticated using (public.is_store_admin());
drop policy if exists "public read store settings" on public.store_settings;
create policy "public read store settings" on public.store_settings for select to anon, authenticated using (true);
drop policy if exists "admins update store settings" on public.store_settings;
create policy "admins update store settings" on public.store_settings for update to authenticated using (public.is_store_admin()) with check (public.is_store_admin());
drop policy if exists "admins insert store settings" on public.store_settings;
create policy "admins insert store settings" on public.store_settings for insert to authenticated with check (public.is_store_admin());
drop policy if exists "public read active products" on public.products;
create policy "public read active products" on public.products for select to anon, authenticated using (active = true or public.is_store_admin());
drop policy if exists "admins insert products" on public.products;
create policy "admins insert products" on public.products for insert to authenticated with check (public.is_store_admin());
drop policy if exists "admins update products" on public.products;
create policy "admins update products" on public.products for update to authenticated using (public.is_store_admin()) with check (public.is_store_admin());
drop policy if exists "admins delete products" on public.products;
create policy "admins delete products" on public.products for delete to authenticated using (public.is_store_admin());

grant select on public.products, public.store_settings to anon, authenticated;
grant insert, update, delete on public.products to authenticated;
grant insert, update on public.store_settings to authenticated;
grant select on public.admin_users to authenticated;

-- Create a public bucket for product images in Storage UI named: product-images
-- Bucket can be public for reading product photos; write access must be limited to admins.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('product-images', 'product-images', true, 5242880, array['image/jpeg','image/png','image/webp','image/avif'])
on conflict (id) do nothing;

drop policy if exists "public can view product images" on storage.objects;
create policy "public can view product images" on storage.objects for select using (bucket_id = 'product-images');
drop policy if exists "admins upload product images" on storage.objects;
create policy "admins upload product images" on storage.objects for insert to authenticated with check (bucket_id = 'product-images' and public.is_store_admin());
drop policy if exists "admins update product images" on storage.objects;
create policy "admins update product images" on storage.objects for update to authenticated using (bucket_id = 'product-images' and public.is_store_admin()) with check (bucket_id = 'product-images' and public.is_store_admin());
drop policy if exists "admins delete product images" on storage.objects;
create policy "admins delete product images" on storage.objects for delete to authenticated using (bucket_id = 'product-images' and public.is_store_admin());
